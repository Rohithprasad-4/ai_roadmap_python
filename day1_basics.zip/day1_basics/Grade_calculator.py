a = int(input("enter the marks: "))
if (100 > a > 90):
    print("Its O grade: ")
elif (90 > a > 80):
    print("Its A+ grade: ")
elif (80 > a > 70):
    print("Its A grade: ")
elif (70 > a > 60):
    print("Its B+ grade: ")
elif (60 > a > 50):
    print("Its B grade: ")
elif (50 > a > 40):
    print("Its C grade: ")
elif (40 > a > 30):
    print("Its D grade: ")
elif (30 >= a ):
    print("Its F grade: ")