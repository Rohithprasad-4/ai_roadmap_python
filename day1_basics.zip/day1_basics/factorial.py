a = int(input("enter a number"))
result = 1
i = 1

while i <= a:
    result = i*result
    i = i + 1
print("factrial of ",result)