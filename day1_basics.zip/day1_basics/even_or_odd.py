#even or odd
a = int(input("enter a number: "))
if a % 2 == 0:
    print("Its a even number")
elif a == 0:
    print("its a zero")
else:
    print("its a odd number")
   