#add two nnumber
a = int(input("enter the number a: "))
b = int(input("enter the number b: "))
sum = a + b
print("the sum is" , sum)