a = [1,2,3,4,5]
a.reverse()
print(a)

#without any fun
b = [1,2,3,4,5]
c = b[::-1]
print(c)